%% Create the Autocorrelation for a 3D matrix. Use un-normlized autocorrelation in order to 
%  preserve the relative intensity information. 
function [AutocorrMatrix_Total] = AutocorrMatrix (RawData, current_MW_location, Width, Height, MW)

AutocorrMatrix_Total = zeros(Width, Height, MW-3);

%Run over each jrajectory
for j = 1:Width
    for i = 1:Height
        
        %Extract time trajectory of one pixel
        trajectory = RawData(i, j, current_MW_location:(current_MW_location+MW-2) );
        
        %uACF over the time trajectory
        uACF_curve = UnNormalizedAutocorr (trajectory,  length(trajectory)-3 );
        
        %Insert the uACF_curve in a new matrix
        AutocorrMatrix_Total(i,j,:) = uACF_curve;
            
    end
end
