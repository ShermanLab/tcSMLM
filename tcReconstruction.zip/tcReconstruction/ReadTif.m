% Reads a tif stack_file into a 3-D matrix
% Simply works faster that importing by Matlab
function RawData = ReadTif(path, length)
    
    %Main loop: read the file
    for i=1:length
        RawData(:,:,i) = imread([path], i);
    end

end