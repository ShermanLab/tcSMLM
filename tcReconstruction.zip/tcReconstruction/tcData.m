%   tcData: use autocorrelation and covariance to enhance spatial information
%   
%   
%   The temporal information based of a certain blinking or bleaching
%   length for each emitter. Otherwise knows as the photophysics of the system. 
%   The choice of the Moving Window (MW) should be done carefully,
%   as it is the main factor impacting the results.
%   
%
%       flourophore: 
%           The raw data, inserted as a matlab 3D matrix.
%
%       MW
%           See main text and guide for more information.     
%
%       time_step: 
%           Default = 1.
%           (Original movie length)/steps = total number of frames
%           The number of frames should be, at least, the length of the
%           rawdata divided by (1/4) of the blinking length. Therefore, it
%           is recommeded to choose a number of steps no more than (1/4) of
%           the blinking length. 
%           
%       Model:
%           Here, the 'averaged model' is used (See main text)

function tc_Data = tcData (time_step, MW, flourophore)

%Basic parameters
TotalLength = length(flourophore(1,1,:));
width = length(flourophore(:,1,1));
height =  length(flourophore(1,:,1));
    
    %initialize current_rawdata_location, current_pSOFI_plane
    current_rawdata_location = 0;
    current_pSOFI_plane = 0;
    max_i = floor( (TotalLength-MW) / time_step);
    
    
    % Main loop: creating the tcData. Changing the 'parfor' to 'for' in needed
    % if the a 'Parallel Computing Toolbox' is not installed
    parfor i = 1:max_i
        i    
            %Run to the next location in the RawData
            if i == 1
                current_rawdata_location = 1;
                AutocorrMatrix_Temp = AutocorrMatrix (flourophore, current_rawdata_location, width, height, MW);
            else
                current_rawdata_location = time_step*i + 1;
                %Temporary: total of current ACF matrix with certain parameters
                AutocorrMatrix_Temp = AutocorrMatrix (flourophore, current_rawdata_location, width, height, MW);
            end

            %Cov_length: the z axis length of AutocorrMatrix_Temp
%             Cov_Length = length(AutocorrMatrix_Temp(1,1,:));

            %The avaraged model
            Sum  = sum(sum(AutocorrMatrix_Temp));
            Sum = squeeze(Sum);
            Model = Sum;

            %Use the temporary matrix to create one tcData frame
            CovMatrix_Temp = Cov (AutocorrMatrix_Temp, width, height, Model);

            %Fill the temp tcData movie
            TempMovie{i} = CovMatrix_Temp;
    end

    % Create the final tcData
    tc_Data = zeros(width, height, max_i);
    for j=1:max_i
        tc_Data(:,:,j)=cell2mat(TempMovie(j));
    end

end
 
    
    