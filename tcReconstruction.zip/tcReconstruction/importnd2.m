%% Import an ND2 file using Imagej. Create a .tif file in the .nd2 folder and a 3D matlab matrix (RawData)
%
% path = the full nd2 path
% name = The .nd2 file name without suffix
% length = RawData length; could be partial
% Layer_num = The .nd2 layer you wish to import 

function RawData = Import_nd2 (path, name, length, Layer_num)
    
    %MIJ has to be installed. See user manual instructions.
    Miji;
    
    %Create a Tif file from the ND2
    formatspec = '%s%s%s%s%s%d%s';
    string_macro_openND2 = sprintf(formatspec, 'open=[', path, name, '.nd2', '] color_mode=Default rois_import=[ROI manager] specify_range split_channels view=Hyperstack stack_order=XYCZT z_begin=1 z_end=', length, ' z_step=1');
    MIJ_string_openND2 = ['path=', string_macro_openND2];
    MIJ.run('Bio-Formats Importer', MIJ_string_openND2);
    
    %Select the RawData
    formatspec = '%s%s%s';
    string_macro_relevant_window = sprintf(formatspec, name, '.nd2 - C=', Layer_num);
    MIJ.selectWindow(string_macro_relevant_window);
    
    %Create a tif file
    formatspec = '%s%s%s%s';
    string_macro_tif = sprintf(formatspec, 'save=[', path, name, '.tif] export compression=Uncompressed');
    MIJ.run('Bio-Formats Exporter', string_macro_tif);
    
    %Import the tif file as a 3D matlab matrix (RawData)
    formatspec = '%s%s%s';
    string_full_pathname = sprintf(formatspec, path, name, '.tif');
    RawData = ReadTif(string_full_pathname, length);
    
    %Close all imagej windows - get ready for the next file
    MIJ.closeAllWindows;
    MIJ.exit();
    
end
