% Extract the corrolative information using cov function. 
% return a 2D matrix (CovMatrix).
%
% temporal_matrix = uACF information for one MW shift. 3D matrix.
%
% width = the width of the matrix
% height = the height of the matrix
% length = the length of the matrix
%
% Model = The model for the specific MW shift
%
function CovMatrix = Cov (temporal_matrix, width, height, Model)

for i = 1:width
    for j = 1:height
        
        %a specific (i,j) uACF trajectory
        uACF_curve = temporal_matrix(i,j,:);
        uACF_curve = reshape(uACF_curve, [1, size(uACF_curve, 3)]);
        
        %Correlate the information
        a = cov (uACF_curve, Model);
        CovMatrix_temp(i,j) = a(2);
    end
end

CovMatrix = CovMatrix_temp;