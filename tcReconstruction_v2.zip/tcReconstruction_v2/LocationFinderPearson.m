%% If the linear correlation (pearson) is smaller than 0.9 (-0.9): the
%  graph is not linear. 0.8 has been chosen as the cutfoff and therefore at
%  that point the MW is chosen. 
function MW = LocationFinderPearson(logACFvalues)

    for i = 10:length(logACFvalues)
            R = corrcoef(1:i, logACFvalues(1:i));
            r = R(2);
            if r > 0 & r < 0.9
                break;
            else if r < 0 & r > -0.9
                break;
            end
            
            
            end
    end
    
    if i == 10
        MW = 0;
    else
        MW = i;
    end
    
end