%Insert two arrayes of x[] and y[], and recieve the figures:
% ACF
% abs(logACF)
% Cutoff: shows the MW for each trajectory.  
%
% x = vector with the x values of chosen pixels;
% y = the y_values of the trajectories chosen
% 
% Note: It is important to choose at least 4 trajectories. MW lower than 20
% should be ignored.
%
% smooth: the 'moving average' interval. In clear data should be 5-10. In
% very noisy data 15-20.

function [slope] = FindBestMovingWindow(x, y, smooth, rawdata)

    %Basic parameters
    rawdatalength = size(rawdata, 3);
    beginning = 1;
    
    %Define colors
    color_1 = [237, 125, 49]./255;
    color_2 = [255, 51, 153]./255;
    color_3 = [255, 0, 255]./255;
    color_4 = [112, 240, 16]./255;
    color_array = [color_1; color_2; color_3; color_4];
    
    for colorIndex = 1:length(x)
        
         if colorIndex > 4
             color{colorIndex} = color_array(colorIndex-4, :);
         else
             color{colorIndex} = color_array(colorIndex, :);
         end
         
    end

    %ACF fig.
    figure;
    for j = 1:length(x)
        x_text = num2str(x(j));
        y_text = num2str(y(j));    
        subplot(1,length(x), j)
        px = rawdata(y(j),x(j), beginning:end);
        %%autocorr - get the auto correlation of the given Intensity
        l = length(px);
        AutocorrelatedIntensity = autocorr(px, l-1);
        AutocorrelatedIntensity = AutocorrelatedIntensity(2:length(AutocorrelatedIntensity));
        
        MoveMeanACF = movmean(AutocorrelatedIntensity, smooth);        
        
        plot(MoveMeanACF, '.', 'Color', color{j});
        xlabel('Time (frames)', 'FontSize', 20);
        ylabel('ACF', 'FontSize', 20);
        legend(['(', x_text, ' , ', y_text ,')']);
        axis([0 rawdatalength/2 0 1])
        set(gca, 'FontSize', 25);
        hold on;
    end
    hold off;

    %abs(ACF) fig
    figure;
    for j = 1:length(x)
        subplot(1,length(x), j)
        x_text = num2str(x(j));
        y_text = num2str(y(j)); 
        px = rawdata(y(j),x(j), beginning:end);
        %%autocorr - get the auto correlation of the given Intensity
        l = length(px);
        AutocorrelatedIntensity = autocorr(px, l-1);
        AutocorrelatedIntensity = AutocorrelatedIntensity(2:length(AutocorrelatedIntensity));
        logACF = abs(log(AutocorrelatedIntensity));
        logACF = movmean(logACF, smooth);
        plot(logACF, '.', 'Color', color{j});
        legend(['(', x_text, ' , ', y_text ,')']);
        xlabel('Time (frames)', 'FontSize', 20);
        ylabel('|log(ACF)|', 'FontSize', 20);
        axis([0 rawdatalength/2 0 3])
        set(gca, 'FontSize', 25);
    end

    
    figure;
    for j = 1:length(x)
        subplot(1,length(x), j)
        x_text = num2str(x(j));
        y_text = num2str(y(j)); 
        px = rawdata(y(j),x(j), beginning:end);
        %%autocorr - get the auto correlation of the given Intensity
        l = length(px);
        AutocorrelatedIntensity = autocorr(px, l-1);
        AutocorrelatedIntensity = AutocorrelatedIntensity(2:length(AutocorrelatedIntensity));
        logACF = abs(log(AutocorrelatedIntensity));

        MoveMeanlogACF = movmean(logACF, smooth);

        [slope] = Slope(MoveMeanlogACF, smooth+10);

        MoveMeanslope = movmean(slope, smooth);

        plot(MoveMeanslope, '.', 'Color', color{j});
        hold on
        legend(['(', x_text, ' , ', y_text ,')']);
        xlabel('Time (frames)', 'FontSize', 20);
        ylabel('Slope (|log(ACF)|)', 'FontSize', 20);
        axis([0 rawdatalength/2 -0.1 0.1])
        set(gca, 'FontSize', 25);
        [location] = PercentageError(MoveMeanslope, 25);
        LocationText = num2str(location);
        vline(location,'black');
        text(location, -0.05, ['Cutoff = ', LocationText], 'FontSize', 18)
    end

end